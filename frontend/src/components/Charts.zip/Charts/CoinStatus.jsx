import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";

const CoinStatus = ({ coinSymbol }) => {
  const [coinData, setCoinData] = useState({
    currentPrice: null,
    openPrice: null,
    highPrice: null,
    lowPrice: null,
    priceChange: null,
    priceChangePercent: null,
  });

  const isDarkMode = useSelector((state) => state.theme.isDarkMode); // Redux 상태 구독

  // WebSocket 설정
  useEffect(() => {
    const socketUrl = `wss://stream.binance.com:9443/ws/${coinSymbol.toLowerCase()}usdt@ticker`;
    const socket = new WebSocket(socketUrl);

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setCoinData({
        currentPrice: parseFloat(data.c),
        openPrice: parseFloat(data.o),
        highPrice: parseFloat(data.h),
        lowPrice: parseFloat(data.l),
        priceChange: parseFloat(data.p),
        priceChangePercent: parseFloat(data.P),
      });
    };

    return () => socket.close();
  }, [coinSymbol]);

  // 스타일 동적 생성
  const themeStyles = {
    backgroundColor: isDarkMode ? "#333" : "#f9f9f9",
    textColor: isDarkMode ? "#f9f9f9" : "#333",
    labelColor: isDarkMode ? "#cccccc" : "#555",
    valueColor: isDarkMode ? "#ffffff" : "#333",
    borderColor: isDarkMode ? "#555" : "#ddd",
    boxShadow: isDarkMode
      ? "0 4px 6px rgba(0, 0, 0, 0.5)"
      : "0 4px 6px rgba(0, 0, 0, 0.1)",
    loadingColor: isDarkMode ? "#aaaaaa" : "#777",
  };

  const getContainerStyle = () => ({
    ...styles.container,
    backgroundColor: themeStyles.backgroundColor,
    color: themeStyles.textColor,
    borderColor: themeStyles.borderColor,
    boxShadow: themeStyles.boxShadow,
  });

  const fields = [
    { label: "현재가", value: coinData.currentPrice, prefix: "$" },
    { label: "시가", value: coinData.openPrice, prefix: "$" },
    { label: "고가", value: coinData.highPrice, prefix: "$" },
    { label: "저가", value: coinData.lowPrice, prefix: "$" },
    {
      label: "변동",
      value: coinData.priceChange
        ? `${coinData.priceChange.toFixed(2)} (${coinData.priceChangePercent.toFixed(2)}%)`
        : null,
      style: {
        color: coinData.priceChange > 0 ? "limegreen" : "orangered",
      },
    },
  ];

  return (
    <div style={getContainerStyle()}>
      <h2 style={{ ...styles.title, color: themeStyles.textColor }}>
        {coinSymbol.toUpperCase()} / USDT
      </h2>
      {fields.map((field, index) => (
        <div style={styles.row} key={index}>
          <span style={{ ...styles.label, color: themeStyles.labelColor }}>
            {field.label}:
          </span>
          <span
            style={{
              ...styles.value,
              color: field.value ? themeStyles.valueColor : themeStyles.loadingColor,
              ...field.style,
            }}
          >
            {field.value ? `${field.prefix || ""}${field.value}` : "Loading..."}
          </span>
        </div>
      ))}
    </div>
  );
};

const styles = {
  container: {
    padding: "20px",
    border: "1px solid",
    borderRadius: "8px",
    maxWidth: "300px",
    backgroundColor: "#f9f9f9",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
  },
  title: {
    fontSize: "20px",
    fontWeight: "bold",
    marginBottom: "10px",
    textAlign: "center",
  },
  row: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "8px",
  },
  label: {
    fontWeight: "bold",
    color: "#555",
  },
  value: {
    fontWeight: "bold",
    color: "#333",
  },
};

export default CoinStatus;
