import React from "react";
import { motion } from "framer-motion";
import AssetChart from "./AssetChart.jsx";

const ChartsGrid = ({ charts, isDarkMode }) => {
const getGridCols = () => {
  const count = charts.length;
  if (count === 1) return "grid-cols-1";
  if (count === 2) return "grid-cols-2"; // 항상 2열
  return "grid-cols-2 lg:grid-cols-2"; // 2열 유지
};
  return (
    <motion.div
      className={`p-4 rounded-lg ${
        isDarkMode
          ? "border-gray-700 bg-gradient-to-r from-gray-800 to-gray-700"
          : "border-gray-300 bg-gradient-to-r from-white to-gray-100"
      }`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className={`grid ${getGridCols()} gap-4`}>
        {charts.map((chart) => (
          <motion.div
            key={chart.id}
            className={`rounded-lg shadow ${
              isDarkMode ? "bg-gray-800" : "bg-white"
            }`}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
          >
<AssetChart
  category={chart.type}
  symbol={chart.symbol}
  style={{ width: "100%", height: "100%" }}
/>          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default React.memo(ChartsGrid);
