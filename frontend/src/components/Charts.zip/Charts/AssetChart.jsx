// AssetChart.jsx

import React, { useState, useEffect, useRef, useCallback, useMemo, memo } from "react";
import Highcharts from "highcharts/highstock";
import HighchartsReact from "highcharts-react-official";
import axios from "axios";
import { useSelector } from "react-redux";

// Highcharts 모듈 임포트
import Exporting from "highcharts/modules/exporting";
import ExportData from "highcharts/modules/export-data";
import Accessibility from "highcharts/modules/accessibility";

// Highcharts 모듈 초기화
if (typeof Exporting === "function") {
  Exporting(Highcharts);
}

if (typeof ExportData === "function") {
  ExportData(Highcharts);
}

if (typeof Accessibility === "function") {
  Accessibility(Highcharts);
}

// 심볼과 한글 이름 매핑 (Upbit 심볼 기준)
const symbolNames = {
  "KRW-BTC": "비트코인",
  "KRW-ETH": "이더리움",
  "KRW-LTC": "라이트코인",
  "KRW-XRP": "리플",
  "KRW-DOGE": "도지코인",
  "KRW-SOL": "솔라나",
  "KRW-DOT": "폴카닷",
  "KRW-ADA": "카르다노",
  "KRW-BCH": "비트코인 캐시",
  "KRW-XLM": "스텔라",
  // 추가 Upbit 심볼 필요 시 여기에 추가
};

const categories = {
  CRYPTO: [
    "KRW-BTC",
    "KRW-ETH",
    "KRW-LTC",
    "KRW-XRP",
    "KRW-DOGE",
    "KRW-SOL",
    "KRW-DOT",
    "KRW-ADA",
    "KRW-BCH",
    "KRW-XLM",
    // 추가 Upbit 심볼 필요 시 여기에 추가
  ],
  // 다른 카테고리도 필요 시 추가
};

// 캐싱을 위한 메모이제이션
const dataCache = {};

const AssetChart = ({ category: initialCategory, symbol: initialSymbol }) => {
  const isDarkMode = useSelector((state) => state.theme.isDarkMode);
  const [category, setCategory] = useState(initialCategory || "CRYPTO");
  const [symbol, setSymbol] = useState(initialSymbol || "KRW-BTC");
  const [series, setSeries] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const chartContainerRef = useRef(null);
  const [chartHeight, setChartHeight] = useState(400);

  // 데이터 패칭 함수
  const fetchData = useCallback(async () => {
    if (!symbol) return;

    setError(null);
    setLoading(true);

    // 캐시에 데이터가 있는지 확인
    const cacheKey = `${category}-${symbol}`;
    if (dataCache[cacheKey]) {
      setSeries([
        {
          name: `${symbolNames[symbol] || symbol} 가격`,
          data: dataCache[cacheKey],
        },
      ]);
      setLoading(false);
      return;
    }

    try {
      const url = `http://127.0.0.1:8000/api/fetch/${symbol}/${category}/`;
      const response = await axios.get(url);
      const fetchedData = response.data.series[0].data.map((item) => [
        new Date(item.x).getTime(),
        item.y[0], // open
        item.y[1], // high
        item.y[2], // low
        item.y[3], // close
      ]);
      dataCache[cacheKey] = fetchedData; // 캐시에 저장
      setSeries([
        {
          name: `${symbolNames[symbol] || symbol} 가격`,
          data: fetchedData,
        },
      ]);
    } catch (err) {
      console.error("데이터 가져오기 오류:", err);
      setError("데이터를 가져오는 데 실패했습니다.");
    } finally {
      setLoading(false);
    }
  }, [symbol, category]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    // 윈도우 리사이즈 이벤트 핸들러
    const updateChartHeight = () => {
      if (chartContainerRef.current) {
        const containerHeight = chartContainerRef.current.offsetHeight;
        setChartHeight(Math.max(containerHeight, 300)); // 최소 높이 설정
      }
    };

    // 초기 높이 설정
    updateChartHeight();

    // 리사이즈 이벤트 등록
    window.addEventListener("resize", updateChartHeight);

    return () => {
      // 리사이즈 이벤트 제거
      window.removeEventListener("resize", updateChartHeight);
    };
  }, []);

  // Highcharts 옵션 설정
  const options = useMemo(() => {
    return {
      chart: {
        type: "candlestick",
        height: chartHeight,
        backgroundColor: "transparent",
      },
      title: {
        text: `${symbolNames[symbol] || symbol} 가격 변동 추이`,
        align: "left",
        style: {
          fontSize: "16px",
          fontWeight: "bold",
          color: isDarkMode ? "#f3f4f6" : "#333333",
        },
      },
      xAxis: {
        type: "datetime",
        labels: {
          style: {
            color: isDarkMode ? "#d1d5db" : "#121212",
            fontSize: "10px",
          },
          formatter: function () {
            return Highcharts.dateFormat("%e %b %Y", this.value);
          },
        },
        gridLineWidth: 1,
        gridLineColor: isDarkMode ? "#374151" : "#e0e0e0",
      },
      yAxis: {
        title: {
          text: "가격 (KRW)",
          style: {
            color: isDarkMode ? "#d1d5db" : "#333333",
            fontSize: "12px",
            fontWeight: "600",
          },
        },
        labels: {
          style: {
            color: isDarkMode ? "#d1d5db" : "#333333",
            fontSize: "10px",
          },
          formatter: function () {
            return `₩${this.value.toLocaleString()}`;
          },
        },
        gridLineWidth: 1,
        gridLineColor: isDarkMode ? "#374151" : "#e0e0e0",
      },
      tooltip: {
        enabled: true,
        shared: true,
        crosshairs: true,
        backgroundColor: isDarkMode ? "rgba(0,0,0,0.7)" : "rgba(255,255,255,0.9)",
        style: {
          color: isDarkMode ? "#ffffff" : "#000000",
        },
        xDateFormat: "%Y-%m-%d %H:%M",
        valueDecimals: 2,
        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: <b>₩{point.y.toLocaleString()}</b><br/>',
      },
      plotOptions: {
        candlestick: {
          color: "#EF403C", // 하락 색상
          upColor: "#0000ff", // 상승 색상
          lineColor: "#404048",
          upLineColor: "#0000ff",
        },
      },
      rangeSelector: {
        selected: 1,
      },
      navigator: {
        enabled: true,
      },
      scrollbar: {
        enabled: true,
      },
      series: [
        {
          type: "candlestick",
          name: `${symbolNames[symbol] || symbol} 가격`,
          data: series[0]?.data || [],
          tooltip: {
            valueDecimals: 2,
          },
        },
      ],
      responsive: {
        rules: [
          {
            condition: {
              maxWidth: 768,
            },
            chartOptions: {
              chart: {
                height: 300,
              },
              xAxis: {
                labels: {
                  style: {
                    fontSize: "8px",
                  },
                },
              },
              yAxis: {
                labels: {
                  style: {
                    fontSize: "8px",
                  },
                },
              },
            },
          },
        ],
      },
    };
  }, [chartHeight, isDarkMode, symbol, series]);

  // WebSocket을 통한 실시간 데이터 수신 (재연결 로직 포함)
  useEffect(() => {
    if (!symbol) return;

    let ws;
    let reconnectInterval = 5000; // 5초 후 재연결 시도

    const connectWebSocket = () => {
      ws = new WebSocket(`ws://localhost:8000/ws/financial_data/${symbol}/`);

      ws.onopen = () => {
        console.log("WebSocket connected");
      };

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        const newPoint = [
          new Date(data.x).getTime(),
          data.y[0], // open
          data.y[1], // high
          data.y[2], // low
          data.y[3], // close
        ];

        setSeries((prevSeries) => {
          if (prevSeries.length === 0) return prevSeries;

          const updatedData = [...prevSeries[0].data, newPoint];

          // 데이터 포인트 수 제한 (예: 최신 500개)
          const MAX_POINTS = 500;
          if (updatedData.length > MAX_POINTS) {
            updatedData.shift();
          }

          // 캐시에 업데이트
          const cacheKey = `${category}-${symbol}`;
          dataCache[cacheKey] = updatedData;

          return [
            {
              ...prevSeries[0],
              data: updatedData,
            },
          ];
        });
      };

      ws.onclose = () => {
        console.log("WebSocket disconnected. Attempting to reconnect...");
        setTimeout(() => {
          connectWebSocket();
        }, reconnectInterval);
      };

      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
        ws.close();
      };
    };

    connectWebSocket();

    return () => {
      if (ws) ws.close();
    };
  }, [symbol, category]);

  return (
    <div className="flex flex-col md:flex-row h-full">
      {/* 좌측 선택기 메뉴 */}
      <div className="w-full md:w-1/5 border-r border-gray-200 dark:border-gray-700 p-2">
        <div className="mb-4">
          <label
            htmlFor="category-select"
            className={`block text-xs font-medium mb-1 ${
              isDarkMode ? "text-gray-300" : "text-gray-700"
            }`}
          >
            대분류 선택
          </label>
          <select
            id="category-select"
            value={category}
            onChange={(e) => {
              setCategory(e.target.value);
              setSymbol(categories[e.target.value][0]); // 첫 번째 심볼 선택
            }}
            className={`w-full border rounded-md p-1 text-xs focus:outline-none focus:ring-1 ${
              isDarkMode
                ? "border-gray-600 bg-gray-700 text-gray-200 focus:ring-blue-500"
                : "border-gray-300 bg-white text-gray-800 focus:ring-blue-500"
            }`}
          >
            {Object.keys(categories).map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label
            className={`block text-xs font-medium mb-1 ${
              isDarkMode ? "text-gray-300" : "text-gray-700"
            }`}
          >
            소분류 선택
          </label>
          <ul className="space-y-1">
            {categories[category].map((sym) => (
              <li key={sym}>
                <button
                  onClick={() => setSymbol(sym)}
                  className={`w-full text-left px-2 py-1 rounded-md text-xs font-medium transition-colors ${
                    sym === symbol
                      ? "bg-blue-500 text-white"
                      : isDarkMode
                      ? "text-gray-200 hover:bg-gray-700"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  {symbolNames[sym] || sym}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* 우측 차트 영역 */}
      <div ref={chartContainerRef} className="flex-1 p-2">
        {loading ? (
          <div className="flex justify-center items-center h-40">로딩 중...</div>
        ) : error ? (
          <div className="text-red-500 text-center">에러: {error}</div>
        ) : (
          <HighchartsReact
            highcharts={Highcharts}
            constructorType={"stockChart"}
            options={options}
            containerProps={{ style: { height: chartHeight, width: "100%" } }}
          />
        )}
      </div>
    </div>
  );
};

export default memo(AssetChart);
