import React, { useState } from "react";

const AssetSelector = ({ categories, category, symbol, setCategory, setSymbol, isDarkMode }) => {
  return (
    <div className="w-full space-y-4">
      {/* 대분류 선택기 */}
      <div className="space-y-1">
        <label
          htmlFor="category-select"
          className={`block text-xs font-medium ${
            isDarkMode ? "text-gray-300" : "text-gray-700"
          }`}
        >
          대분류 선택
        </label>
        <select
          id="category-select"
          value={category}
          onChange={(e) => {
            const selectedCategory = e.target.value;
            setCategory(selectedCategory);
            setSymbol(categories[selectedCategory][0]); // 대분류 변경 시 첫 소분류 기본 선택
          }}
          className={`w-full border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-1 ${
            isDarkMode
              ? "border-gray-600 bg-gray-700 text-gray-200 focus:ring-blue-500"
              : "border-gray-300 bg-white text-gray-800 focus:ring-blue-500"
          }`}
        >
          {Object.keys(categories).map((key) => (
            <option key={key} value={key}>
              {key}
            </option>
          ))}
        </select>
      </div>

      {/* 소분류 선택기 */}
      <div className="space-y-1">
        <label
          className={`block text-xs font-medium ${
            isDarkMode ? "text-gray-300" : "text-gray-700"
          }`}
        >
          소분류 선택
        </label>
        <ul className="space-y-1">
          {categories[category]?.map((sym) => (
            <li key={sym}>
              <button
                onClick={() => setSymbol(sym)}
                className={`w-full text-left px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                  sym === symbol
                    ? "bg-blue-500 text-white"
                    : isDarkMode
                    ? "text-gray-200 hover:bg-gray-700"
                    : "text-gray-700 hover:bg-gray-100"
                }`}
              >
                {sym}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AssetSelector;
