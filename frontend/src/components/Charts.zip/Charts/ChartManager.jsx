import React, { useState, useCallback } from "react";
import { motion } from "framer-motion";
import ChartsGrid from "./ChartsGrid.jsx";

const ChartManager = ({ isDarkMode }) => {
  const [charts, setCharts] = useState([{ id: 1 }]);

  // Add chart function (up to 4 charts)
  const addChart = useCallback(() => {
    setCharts((prevCharts) => {
      if (prevCharts.length >= 4) return prevCharts; // Limit to 4 charts
      const newId = prevCharts.length > 0 ? prevCharts[prevCharts.length - 1].id + 1 : 1;
      return [...prevCharts, { id: newId }];
    });
  }, []);

  // Remove chart function
  const removeChart = useCallback(() => {
    setCharts((prevCharts) => {
      if (prevCharts.length <= 1) return prevCharts; // Keep at least 1 chart
      return prevCharts.slice(0, -1);
    });
  }, []);

  return (
    <div>
      {/* 차트 컨트롤 */}
      <section className="flex justify-end space-x-3 mb-4">
        <button
          onClick={addChart}
          disabled={charts.length >= 4}
          className={`px-3 py-1.5 rounded-md text-sm font-medium focus:outline-none focus:ring-2 ${
            charts.length >= 4
              ? "bg-gray-400 text-gray-700 cursor-not-allowed"
              : "bg-blue-600 text-white hover:bg-blue-700"
          }`}
        >
          차트 추가
        </button>
        <button
          onClick={removeChart}
          disabled={charts.length <= 1}
          className={`px-3 py-1.5 rounded-md text-sm font-medium focus:outline-none focus:ring-2 ${
            charts.length <= 1
              ? "bg-gray-400 text-gray-700 cursor-not-allowed"
              : "bg-red-600 text-white hover:bg-red-700"
          }`}
        >
          차트 제거
        </button>
      </section>

      {/* 동적 차트 */}
      <ChartsGrid charts={charts} isDarkMode={isDarkMode} />
    </div>
  );
};

export default React.memo(ChartManager);
